import tkinter as tk
from tkinter import messagebox

# Functions
def add_task():
    task = task_entry.get().strip()
    if task:
        list_box.insert(tk.END, task)
        task_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Warning", "⚠️ Task cannot be empty.")

def delete_task():
    try:
        selected_index = list_box.curselection()[0]
        list_box.delete(selected_index)
    except IndexError:
        messagebox.showwarning("Warning", "📭 No task selected to delete.")

def mark_completed():
    try:
        selected_index = list_box.curselection()[0]
        task = list_box.get(selected_index)
        # If not already marked, add ✔
        if not task.startswith("✔"):
            list_box.delete(selected_index)
            list_box.insert(selected_index, f"✔ {task}")
    except IndexError:
        messagebox.showwarning("Warning", "📭 No task selected to mark as completed.")

# Main Window
window = tk.Tk()
window.geometry("500x500")
window.title("To Do List Manager")
icon = tk.PhotoImage(file="todo.png")
window.iconphoto(1, icon)
window.config(bg="#d2dff7")
window.maxsize(750,630)
window.minsize(500,500)

photo = tk.PhotoImage(file = "todo.png")
# Title Label
title_label = tk.Label(window, text=" To Do List Manager",
                       font=("Comic Sans MS", 30, "bold"),
                       bg="#5c8fed", fg="white" , image=photo , compound="left")
title_label.pack(fill="x")

# Entry Frame
entry_frame = tk.Frame(window, bg="#d2dff7")
entry_frame.pack(pady=15)

task_label = tk.Label(entry_frame, text="Enter Task:",
                      font=("Comic Sans MS", 14, "bold"),
                      fg="black", bg="#d2dff7", padx=5)
task_label.pack(side="left")

task_entry = tk.Entry(entry_frame, width=20,
                      font=("Comic Sans MS", 14, "bold"),
                      bd=2, relief="sunken" , bg = "#fdf2b3")
task_entry.pack(side="left", padx=5)

add_button = tk.Button(entry_frame, text="➕ Add",
                       fg="white", bg="green",
                       font=("Comic Sans MS", 10, "bold"),
                       bd=5, relief="raised",
                       command=add_task)
add_button.pack(side="left", padx=5)

# Button Frame
button_frame = tk.Frame(window, bg="#d2dff7")
button_frame.pack(pady=20)

delete_button = tk.Button(button_frame, text="❌ Delete",
                          fg="white", bg="red",
                          font=("Comic Sans MS", 11, "bold"),
                          bd=5, relief="raised",
                          command=delete_task)
delete_button.pack(side="left", padx=5)

complete_button = tk.Button(button_frame, text="✔ Mark Completed",
                            fg="white", bg="#1e90ff",
                            font=("Comic Sans MS", 11, "bold"),
                            bd=5, relief="raised",
                            command=mark_completed)
complete_button.pack(side="left", padx=5)

exit_button = tk.Button(button_frame, text="Exit ➜]",
                        fg="white", bg="#717274",
                        font=("Comic Sans MS", 11, "bold"),
                        bd=5, relief="raised",
                        command=window.quit)
exit_button.pack(side="left", padx=5)

# List Frame
list_frame = tk.Frame(window)
list_frame.pack(pady=25)

list_box = tk.Listbox(list_frame, width=60, height=17,
                      selectbackground="#C5C3C2",
                      bg="#fdf2b3", bd=5, relief="sunken", foreground="black", selectforeground="black",
                      font=("Comic Sans MS", 15, "bold"))
list_box.pack()

window.mainloop()
